//
//  main.m
//  DemoApp
//
//  Created by Yosuke Ishikawa on 2013/03/05.
//  Copyright (c) 2013年 Yosuke Ishikawa. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ISAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ISAppDelegate class]));
    }
}
