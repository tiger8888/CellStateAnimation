#import <UIKit/UIKit.h>

@interface ISViewController : UITableViewController

@property (nonatomic, strong) NSArray *array;

@end
